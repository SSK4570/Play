# NEXPLAYER+ 📺

**Package:** `com.nex.player.ssk`

A powerful IPTV player for Android with M3U playlist support, ExoPlayer, and EPG.

---

## ✨ Features

| Feature | Details |
|---|---|
| M3U/M3U8 Support | Add any M3U URL — auto-parsed |
| EPG Support | Reads `url-tvg` from M3U header or XMLTV URL |
| ExoPlayer | HLS, DASH, RTSP stream support |
| Groups | Channel categories with filter chips |
| Search | Search channels by name |
| Favorites | Star channels for quick access |
| Recent | Tracks last-watched channels |
| Multi-playlist | Add multiple M3U sources |
| Dark Theme | Deep dark UI with teal accent |

---

## 🛠️ Build on GitHub (Auto-sign APK)

### Step 1: Create GitHub Repository
```
1. Go to github.com → New Repository
2. Name it: NEXPLAYER_PLUS
3. Push this code
```

### Step 2: Push Code
```bash
cd NEXPLAYER_PLUS
git init
git add .
git commit -m "Initial NEXPLAYER+ release"
git remote add origin https://github.com/YOUR_USERNAME/NEXPLAYER_PLUS.git
git push -u origin main
```

### Step 3: GitHub Actions builds APK automatically!
- Go to **Actions** tab in your repo
- Watch the build run
- Download APK from **Artifacts**

### Step 4: Release with tag
```bash
git tag v1.0.0
git push origin v1.0.0
```
→ GitHub will create a Release with the APK automatically!

---

## 🔑 Custom Keystore (Optional)

The build auto-generates a test keystore. For a permanent key:

```bash
# Generate your own keystore
keytool -genkeypair -v -keystore my_key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias nexplayer_key \
  -storepass YOUR_STORE_PASS \
  -keypass YOUR_KEY_PASS

# Encode to base64
base64 -i my_key.jks | tr -d '\n'
```

Add to GitHub Secrets (**Settings → Secrets → Actions**):
| Secret | Value |
|---|---|
| `KEYSTORE_BASE64` | Base64 output above |
| `KEYSTORE_PASSWORD` | Your store password |
| `KEY_ALIAS` | `nexplayer_key` |
| `KEY_PASSWORD` | Your key password |

---

## 📱 Usage

1. Open NEXPLAYER+
2. Tap **+** button
3. Enter playlist name & M3U URL
4. Channels load automatically
5. Tap a channel → plays instantly

---

## 🏗️ Project Structure

```
app/
├── data/
│   ├── model/      # Channel, Playlist, EpgProgram, Room DB
│   └── repository/ # PlaylistRepository, EpgRepository
├── ui/
│   ├── home/       # MainActivity, ViewModel, Adapters
│   ├── player/     # PlayerActivity (ExoPlayer)
│   └── playlist/   # PlaylistActivity (manage)
└── util/
    ├── M3uParser.kt  # Parses M3U/M3U8 files
    └── EpgParser.kt  # Parses XMLTV EPG data
```
