package com.nex.player.ssk.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.nex.player.ssk.R
import com.nex.player.ssk.data.model.Channel
import com.nex.player.ssk.databinding.ItemChannelBinding

class ChannelAdapter(
    private val onChannelClick: (Channel) -> Unit,
    private val onFavoriteClick: (Channel) -> Unit
) : ListAdapter<Channel, ChannelAdapter.ViewHolder>(DIFF) {

    inner class ViewHolder(private val binding: ItemChannelBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(channel: Channel) {
            binding.tvChannelName.text = channel.name
            binding.tvGroupName.text = channel.group
            binding.tvEpgTitle.text = "" // Will be populated by EPG

            Glide.with(binding.ivLogo)
                .load(channel.logoUrl)
                .placeholder(R.drawable.ic_channel_placeholder)
                .error(R.drawable.ic_channel_placeholder)
                .into(binding.ivLogo)

            binding.ivFavorite.setImageResource(
                if (channel.isFavorite) R.drawable.ic_favorite_filled
                else R.drawable.ic_favorite_outline
            )

            binding.root.setOnClickListener { onChannelClick(channel) }
            binding.ivFavorite.setOnClickListener { onFavoriteClick(channel) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemChannelBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Channel>() {
            override fun areItemsTheSame(a: Channel, b: Channel) = a.id == b.id
            override fun areContentsTheSame(a: Channel, b: Channel) = a == b
        }
    }
}

class GroupAdapter(
    private val onGroupClick: (String) -> Unit
) : ListAdapter<String, GroupAdapter.ViewHolder>(DIFF) {

    private var selectedPosition = 0

    inner class ViewHolder(private val binding: com.nex.player.ssk.databinding.ItemGroupChipBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(group: String, isSelected: Boolean) {
            binding.chip.text = group
            binding.chip.isChecked = isSelected
            binding.chip.setOnClickListener {
                val prev = selectedPosition
                selectedPosition = adapterPosition
                notifyItemChanged(prev)
                notifyItemChanged(adapterPosition)
                onGroupClick(group)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = com.nex.player.ssk.databinding.ItemGroupChipBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position), position == selectedPosition)
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<String>() {
            override fun areItemsTheSame(a: String, b: String) = a == b
            override fun areContentsTheSame(a: String, b: String) = a == b
        }
    }
}

class PlaylistAdapter(
    private val onPlaylistClick: (com.nex.player.ssk.data.model.Playlist) -> Unit
) : ListAdapter<com.nex.player.ssk.data.model.Playlist, PlaylistAdapter.ViewHolder>(DIFF) {

    private var selectedId = -1L

    inner class ViewHolder(private val binding: com.nex.player.ssk.databinding.ItemPlaylistChipBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(playlist: com.nex.player.ssk.data.model.Playlist, isSelected: Boolean) {
            binding.chip.text = playlist.name
            binding.chip.isChecked = isSelected
            binding.chip.setOnClickListener {
                selectedId = playlist.id
                notifyDataSetChanged()
                onPlaylistClick(playlist)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = com.nex.player.ssk.databinding.ItemPlaylistChipBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val playlist = getItem(position)
        if (selectedId == -1L && position == 0) selectedId = playlist.id
        holder.bind(playlist, playlist.id == selectedId)
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<com.nex.player.ssk.data.model.Playlist>() {
            override fun areItemsTheSame(a: com.nex.player.ssk.data.model.Playlist, b: com.nex.player.ssk.data.model.Playlist) = a.id == b.id
            override fun areContentsTheSame(a: com.nex.player.ssk.data.model.Playlist, b: com.nex.player.ssk.data.model.Playlist) = a == b
        }
    }
}
