package com.nex.player.ssk.ui.playlist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.nex.player.ssk.NexPlayerApp
import com.nex.player.ssk.R
import com.nex.player.ssk.data.model.Playlist
import com.nex.player.ssk.databinding.ActivityPlaylistBinding
import com.nex.player.ssk.databinding.DialogAddPlaylistBinding
import com.nex.player.ssk.databinding.ItemPlaylistManageBinding
import kotlinx.coroutines.launch

class PlaylistActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlaylistBinding
    private lateinit var adapter: ManagePlaylistAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlaylistBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.my_playlists)

        adapter = ManagePlaylistAdapter(
            onEdit = { showEditDialog(it) },
            onDelete = { confirmDelete(it) },
            onRefresh = { refreshPlaylist(it) }
        )
        binding.rvPlaylists.layoutManager = LinearLayoutManager(this)
        binding.rvPlaylists.adapter = adapter

        binding.fabAdd.setOnClickListener { showAddDialog() }
        loadPlaylists()
    }

    private fun loadPlaylists() {
        lifecycleScope.launch {
            val app = application as NexPlayerApp
            val lists = app.playlistRepository.getAllPlaylists()
            adapter.submitList(lists)
        }
    }

    private fun showAddDialog() {
        val dialogBinding = DialogAddPlaylistBinding.inflate(layoutInflater)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.add_playlist)
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.save) { _, _ ->
                val name = dialogBinding.etName.text.toString().trim()
                val url = dialogBinding.etUrl.text.toString().trim()
                if (name.isNotEmpty() && url.isNotEmpty()) {
                    lifecycleScope.launch {
                        val app = application as NexPlayerApp
                        val result = app.playlistRepository.addPlaylist(name, url)
                        result.onSuccess {
                            app.playlistRepository.refreshPlaylist(it)
                            loadPlaylists()
                            Toast.makeText(this@PlaylistActivity, "Playlist added!", Toast.LENGTH_SHORT).show()
                        }
                        result.onFailure {
                            Toast.makeText(this@PlaylistActivity, "Error: ${it.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showEditDialog(playlist: Playlist) {
        val dialogBinding = DialogAddPlaylistBinding.inflate(layoutInflater)
        dialogBinding.etName.setText(playlist.name)
        dialogBinding.etUrl.setText(playlist.url)
        MaterialAlertDialogBuilder(this)
            .setTitle("Edit Playlist")
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.save) { _, _ ->
                // Update logic would go here
                Toast.makeText(this, "Updated!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirmDelete(playlist: Playlist) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete Playlist")
            .setMessage("Delete \"${playlist.name}\"? This will remove all its channels.")
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    val app = application as NexPlayerApp
                    app.playlistRepository.deletePlaylist(playlist)
                    loadPlaylists()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun refreshPlaylist(playlist: Playlist) {
        lifecycleScope.launch {
            Toast.makeText(this@PlaylistActivity, "Refreshing...", Toast.LENGTH_SHORT).show()
            val app = application as NexPlayerApp
            val result = app.playlistRepository.refreshPlaylist(playlist)
            result.onSuccess {
                Toast.makeText(this@PlaylistActivity, "$it channels loaded", Toast.LENGTH_SHORT).show()
                loadPlaylists()
            }
            result.onFailure {
                Toast.makeText(this@PlaylistActivity, "Error: ${it.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}

class ManagePlaylistAdapter(
    private val onEdit: (Playlist) -> Unit,
    private val onDelete: (Playlist) -> Unit,
    private val onRefresh: (Playlist) -> Unit
) : ListAdapter<Playlist, ManagePlaylistAdapter.VH>(DIFF) {

    inner class VH(val binding: ItemPlaylistManageBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(p: Playlist) {
            binding.tvName.text = p.name
            binding.tvUrl.text = p.url
            binding.tvCount.text = "${p.channelCount} channels"
            binding.ibEdit.setOnClickListener { onEdit(p) }
            binding.ibDelete.setOnClickListener { onDelete(p) }
            binding.ibRefresh.setOnClickListener { onRefresh(p) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(
        ItemPlaylistManageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Playlist>() {
            override fun areItemsTheSame(a: Playlist, b: Playlist) = a.id == b.id
            override fun areContentsTheSame(a: Playlist, b: Playlist) = a == b
        }
    }
}
