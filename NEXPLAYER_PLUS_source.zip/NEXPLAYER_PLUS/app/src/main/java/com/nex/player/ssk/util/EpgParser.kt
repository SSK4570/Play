package com.nex.player.ssk.util

import android.util.Xml
import com.nex.player.ssk.data.model.EpgProgram
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

object EpgParser {

    private val dateFormats = listOf(
        SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US),
        SimpleDateFormat("yyyyMMddHHmmss", Locale.US),
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US),
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).also {
            it.timeZone = TimeZone.getTimeZone("UTC")
        }
    )

    fun parse(xmlContent: String, playlistId: Long): List<EpgProgram> {
        val programs = mutableListOf<EpgProgram>()

        try {
            val parser = Xml.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            parser.setInput(StringReader(xmlContent))

            var eventType = parser.eventType
            var currentChannel = ""
            var title = ""
            var description = ""
            var startTime = 0L
            var endTime = 0L
            var icon = ""
            var inProgramme = false
            var inTitle = false
            var inDesc = false

            while (eventType != XmlPullParser.END_DOCUMENT) {
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        when (parser.name) {
                            "programme" -> {
                                inProgramme = true
                                currentChannel = parser.getAttributeValue(null, "channel") ?: ""
                                startTime = parseTime(parser.getAttributeValue(null, "start") ?: "")
                                endTime = parseTime(parser.getAttributeValue(null, "stop") ?: "")
                                title = ""
                                description = ""
                                icon = ""
                            }
                            "title" -> if (inProgramme) inTitle = true
                            "desc" -> if (inProgramme) inDesc = true
                            "icon" -> if (inProgramme) {
                                icon = parser.getAttributeValue(null, "src") ?: ""
                            }
                        }
                    }
                    XmlPullParser.TEXT -> {
                        when {
                            inTitle -> title = parser.text ?: ""
                            inDesc -> description = parser.text ?: ""
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        when (parser.name) {
                            "programme" -> {
                                if (inProgramme && currentChannel.isNotEmpty() && title.isNotEmpty()) {
                                    programs.add(
                                        EpgProgram(
                                            channelId = currentChannel,
                                            playlistId = playlistId,
                                            title = title,
                                            description = description,
                                            startTime = startTime,
                                            endTime = endTime,
                                            icon = icon
                                        )
                                    )
                                }
                                inProgramme = false
                            }
                            "title" -> inTitle = false
                            "desc" -> inDesc = false
                        }
                    }
                }
                eventType = parser.next()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return programs
    }

    private fun parseTime(timeStr: String): Long {
        if (timeStr.isBlank()) return 0L
        for (fmt in dateFormats) {
            try {
                return fmt.parse(timeStr)?.time ?: 0L
            } catch (_: Exception) {}
        }
        return 0L
    }
}
