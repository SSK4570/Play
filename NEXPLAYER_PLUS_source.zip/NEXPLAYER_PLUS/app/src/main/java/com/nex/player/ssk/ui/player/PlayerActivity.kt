package com.nex.player.ssk.ui.player

import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.nex.player.ssk.NexPlayerApp
import com.nex.player.ssk.R
import com.nex.player.ssk.databinding.ActivityPlayerBinding
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CHANNEL_NAME = "channel_name"
        const val EXTRA_STREAM_URL = "stream_url"
        const val EXTRA_CHANNEL_LOGO = "channel_logo"
        const val EXTRA_CHANNEL_ID = "channel_id"
        const val EXTRA_TVG_ID = "tvg_id"
        const val EXTRA_PLAYLIST_ID = "playlist_id"
    }

    private lateinit var binding: ActivityPlayerBinding
    private var player: ExoPlayer? = null
    private var channelName = ""
    private var streamUrl = ""
    private var logoUrl = ""
    private var channelId = -1L
    private var tvgId = ""
    private var playlistId = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Keep screen on
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // Full-screen immersive
        hideSystemUI()

        channelName = intent.getStringExtra(EXTRA_CHANNEL_NAME) ?: ""
        streamUrl = intent.getStringExtra(EXTRA_STREAM_URL) ?: ""
        logoUrl = intent.getStringExtra(EXTRA_CHANNEL_LOGO) ?: ""
        channelId = intent.getLongExtra(EXTRA_CHANNEL_ID, -1L)
        tvgId = intent.getStringExtra(EXTRA_TVG_ID) ?: ""
        playlistId = intent.getLongExtra(EXTRA_PLAYLIST_ID, -1L)

        setupUI()
        initializePlayer()
        loadEpg()
    }

    private fun setupUI() {
        binding.tvChannelName.text = channelName

        if (logoUrl.isNotEmpty()) {
            Glide.with(this)
                .load(logoUrl)
                .placeholder(R.drawable.ic_channel_placeholder)
                .into(binding.ivChannelLogo)
        }

        binding.ibBack.setOnClickListener { finish() }
        binding.ibLock.setOnClickListener { toggleLock() }
    }

    private fun initializePlayer() {
        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()

        val dataSourceFactory = OkHttpDataSource.Factory(okHttpClient)
            .setDefaultRequestProperties(mapOf("User-Agent" to "NexPlayer+ IPTV"))

        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .build()
            .also { exoPlayer ->
                binding.playerView.player = exoPlayer

                val mediaItem = MediaItem.fromUri(streamUrl)
                exoPlayer.setMediaItem(mediaItem)
                exoPlayer.prepare()
                exoPlayer.playWhenReady = true

                exoPlayer.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        when (playbackState) {
                            Player.STATE_BUFFERING -> {
                                binding.progressBuffer.visibility = View.VISIBLE
                            }
                            Player.STATE_READY -> {
                                binding.progressBuffer.visibility = View.GONE
                                binding.tvBuffering.visibility = View.GONE
                            }
                            Player.STATE_ENDED -> finish()
                            Player.STATE_IDLE -> {}
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        binding.progressBuffer.visibility = View.GONE
                        Toast.makeText(
                            this@PlayerActivity,
                            "Playback error: ${error.message}",
                            Toast.LENGTH_LONG
                        ).show()
                        binding.tvBuffering.text = "Stream error. Check your connection."
                        binding.tvBuffering.visibility = View.VISIBLE
                    }
                })
            }
    }

    private fun loadEpg() {
        if (tvgId.isEmpty()) return
        lifecycleScope.launch {
            val app = application as NexPlayerApp
            val current = app.epgRepository.getCurrentProgram(tvgId)
            current?.let {
                binding.tvEpgNow.text = "▶ ${it.title}"
                val next = app.epgRepository.getProgramsForChannel(tvgId).firstOrNull()
                next?.let { n -> binding.tvEpgNext.text = "Next: ${n.title}" }
            }
        }
    }

    private var isLocked = false
    private fun toggleLock() {
        isLocked = !isLocked
        binding.playerView.useController = !isLocked
        binding.ibLock.setImageResource(
            if (isLocked) R.drawable.ic_lock_closed else R.drawable.ic_lock_open
        )
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
    }

    override fun onStart() { super.onStart(); player?.play() }
    override fun onStop() { super.onStop(); player?.pause() }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }
}
