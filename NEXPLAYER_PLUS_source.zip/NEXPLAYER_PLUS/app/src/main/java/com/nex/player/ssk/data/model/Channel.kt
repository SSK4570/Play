package com.nex.player.ssk.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "channels")
data class Channel(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val playlistId: Long,
    val name: String,
    val streamUrl: String,
    val logoUrl: String = "",
    val group: String = "",
    val tvgId: String = "",
    val tvgName: String = "",
    val epgUrl: String = "",
    val isFavorite: Boolean = false,
    val lastWatched: Long = 0L
)

@Entity(tableName = "playlists")
data class Playlist(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val url: String,
    val lastUpdated: Long = 0L,
    val channelCount: Int = 0
)

@Entity(tableName = "epg_programs")
data class EpgProgram(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val channelId: String,
    val playlistId: Long,
    val title: String,
    val description: String = "",
    val startTime: Long,
    val endTime: Long,
    val icon: String = ""
)

data class ChannelGroup(
    val name: String,
    val channels: List<Channel>,
    val count: Int = channels.size
)

data class ChannelWithEpg(
    val channel: Channel,
    val currentProgram: EpgProgram? = null,
    val nextProgram: EpgProgram? = null
)
