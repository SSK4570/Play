package com.nex.player.ssk.data.model

import android.content.Context
import androidx.room.*

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY id DESC")
    suspend fun getAllPlaylists(): List<Playlist>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: Playlist): Long

    @Delete
    suspend fun deletePlaylist(playlist: Playlist)

    @Update
    suspend fun updatePlaylist(playlist: Playlist)

    @Query("SELECT * FROM playlists WHERE id = :id")
    suspend fun getPlaylistById(id: Long): Playlist?
}

@Dao
interface ChannelDao {
    @Query("SELECT * FROM channels WHERE playlistId = :playlistId ORDER BY `group`, name")
    suspend fun getChannelsByPlaylist(playlistId: Long): List<Channel>

    @Query("SELECT DISTINCT `group` FROM channels WHERE playlistId = :playlistId ORDER BY `group`")
    suspend fun getGroupsByPlaylist(playlistId: Long): List<String>

    @Query("SELECT * FROM channels WHERE playlistId = :playlistId AND `group` = :group ORDER BY name")
    suspend fun getChannelsByGroup(playlistId: Long, group: String): List<Channel>

    @Query("SELECT * FROM channels WHERE playlistId = :playlistId AND (name LIKE '%' || :query || '%' OR tvgName LIKE '%' || :query || '%') ORDER BY name")
    suspend fun searchChannels(playlistId: Long, query: String): List<Channel>

    @Query("SELECT * FROM channels WHERE isFavorite = 1 AND playlistId = :playlistId ORDER BY name")
    suspend fun getFavoriteChannels(playlistId: Long): List<Channel>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannels(channels: List<Channel>)

    @Query("DELETE FROM channels WHERE playlistId = :playlistId")
    suspend fun deleteChannelsByPlaylist(playlistId: Long)

    @Query("UPDATE channels SET isFavorite = :isFavorite WHERE id = :channelId")
    suspend fun updateFavorite(channelId: Long, isFavorite: Boolean)

    @Query("UPDATE channels SET lastWatched = :time WHERE id = :channelId")
    suspend fun updateLastWatched(channelId: Long, time: Long)

    @Query("SELECT * FROM channels WHERE playlistId = :playlistId ORDER BY lastWatched DESC LIMIT 20")
    suspend fun getRecentChannels(playlistId: Long): List<Channel>

    @Query("SELECT COUNT(*) FROM channels WHERE playlistId = :playlistId")
    suspend fun getChannelCount(playlistId: Long): Int
}

@Dao
interface EpgDao {
    @Query("SELECT * FROM epg_programs WHERE channelId = :channelId AND endTime > :now ORDER BY startTime ASC LIMIT 10")
    suspend fun getProgramsForChannel(channelId: String, now: Long): List<EpgProgram>

    @Query("SELECT * FROM epg_programs WHERE channelId = :channelId AND startTime <= :now AND endTime > :now LIMIT 1")
    suspend fun getCurrentProgram(channelId: String, now: Long): EpgProgram?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrograms(programs: List<EpgProgram>)

    @Query("DELETE FROM epg_programs WHERE playlistId = :playlistId")
    suspend fun deleteEpgByPlaylist(playlistId: Long)

    @Query("DELETE FROM epg_programs WHERE endTime < :before")
    suspend fun deleteOldPrograms(before: Long)
}

@Database(
    entities = [Playlist::class, Channel::class, EpgProgram::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao
    abstract fun channelDao(): ChannelDao
    abstract fun epgDao(): EpgDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "nexplayer_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
