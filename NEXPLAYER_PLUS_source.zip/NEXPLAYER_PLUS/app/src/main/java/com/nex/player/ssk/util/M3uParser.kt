package com.nex.player.ssk.util

import com.nex.player.ssk.data.model.Channel

object M3uParser {

    /**
     * Parses M3U/M3U8 playlist content into a list of Channel objects.
     * Supports:
     *   - #EXTINF tags with tvg-id, tvg-name, tvg-logo, group-title, tvg-url
     *   - url-tvg attribute for EPG source
     */
    fun parse(content: String, playlistId: Long): List<Channel> {
        val channels = mutableListOf<Channel>()
        val lines = content.lines()
        var i = 0

        // Check if valid M3U
        if (lines.isEmpty() || !lines[0].trim().startsWith("#EXTM3U")) {
            return channels
        }

        while (i < lines.size) {
            val line = lines[i].trim()

            if (line.startsWith("#EXTINF:")) {
                val info = parseExtInf(line)
                // Find the stream URL (next non-empty, non-comment line)
                var j = i + 1
                while (j < lines.size && (lines[j].trim().isEmpty() || lines[j].trim().startsWith("#"))) {
                    j++
                }
                if (j < lines.size) {
                    val url = lines[j].trim()
                    if (url.isNotEmpty() && (url.startsWith("http") || url.startsWith("rtsp") || url.startsWith("rtmp"))) {
                        channels.add(
                            Channel(
                                playlistId = playlistId,
                                name = info["name"] ?: "Unknown Channel",
                                streamUrl = url,
                                logoUrl = info["tvg-logo"] ?: "",
                                group = info["group-title"] ?: "Uncategorized",
                                tvgId = info["tvg-id"] ?: "",
                                tvgName = info["tvg-name"] ?: info["name"] ?: "",
                                epgUrl = info["tvg-url"] ?: ""
                            )
                        )
                    }
                    i = j + 1
                    continue
                }
            }
            i++
        }

        return channels
    }

    private fun parseExtInf(line: String): Map<String, String> {
        val result = mutableMapOf<String, String>()

        // Extract attributes like tvg-id="...", tvg-name="...", etc.
        val attrRegex = Regex("""([\w-]+)="([^"]*?)"""")
        attrRegex.findAll(line).forEach { match ->
            result[match.groupValues[1].lowercase()] = match.groupValues[2]
        }

        // Extract channel name (after the last comma)
        val lastComma = line.lastIndexOf(',')
        if (lastComma >= 0 && lastComma < line.length - 1) {
            result["name"] = line.substring(lastComma + 1).trim()
        }

        return result
    }

    /**
     * Extracts the EPG URL from #EXTM3U header line if present
     * e.g. #EXTM3U url-tvg="http://epg.example.com/epg.xml.gz"
     */
    fun extractEpgUrl(content: String): String? {
        val firstLine = content.lines().firstOrNull()?.trim() ?: return null
        val match = Regex("""url-tvg="([^"]+)"""").find(firstLine)
        return match?.groupValues?.get(1)
    }
}
