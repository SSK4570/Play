package com.nex.player.ssk

import android.app.Application
import com.nex.player.ssk.data.repository.PlaylistRepository
import com.nex.player.ssk.data.repository.EpgRepository

class NexPlayerApp : Application() {

    val playlistRepository: PlaylistRepository by lazy {
        PlaylistRepository(this)
    }

    val epgRepository: EpgRepository by lazy {
        EpgRepository(this)
    }

    companion object {
        lateinit var instance: NexPlayerApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}
