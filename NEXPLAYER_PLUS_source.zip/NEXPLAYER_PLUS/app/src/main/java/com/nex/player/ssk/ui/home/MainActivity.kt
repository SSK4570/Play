package com.nex.player.ssk.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.nex.player.ssk.NexPlayerApp
import com.nex.player.ssk.R
import com.nex.player.ssk.data.model.Channel
import com.nex.player.ssk.data.model.Playlist
import com.nex.player.ssk.databinding.ActivityMainBinding
import com.nex.player.ssk.databinding.DialogAddPlaylistBinding
import com.nex.player.ssk.ui.player.PlayerActivity
import com.nex.player.ssk.ui.playlist.PlaylistActivity

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var channelAdapter: ChannelAdapter
    private lateinit var groupAdapter: GroupAdapter
    private lateinit var playlistAdapter: PlaylistAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val app = application as NexPlayerApp
        viewModel = ViewModelProvider(
            this,
            MainViewModelFactory(app.playlistRepository, app.epgRepository)
        )[MainViewModel::class.java]

        setupAdapters()
        setupObservers()
        setupClickListeners()
        viewModel.loadPlaylists()
    }

    private fun setupAdapters() {
        // Playlist adapter for the top selector
        playlistAdapter = PlaylistAdapter { playlist ->
            viewModel.selectPlaylist(playlist)
        }
        binding.rvPlaylists.apply {
            layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = playlistAdapter
        }

        // Group adapter
        groupAdapter = GroupAdapter { group ->
            viewModel.selectGroup(group)
        }
        binding.rvGroups.apply {
            layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = groupAdapter
        }

        // Channel adapter
        channelAdapter = ChannelAdapter(
            onChannelClick = { channel -> openPlayer(channel) },
            onFavoriteClick = { channel -> viewModel.toggleFavorite(channel) }
        )
        binding.rvChannels.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = channelAdapter
        }
    }

    private fun setupObservers() {
        viewModel.playlists.observe(this) { playlists ->
            playlistAdapter.submitList(playlists)
            binding.layoutEmpty.visibility = if (playlists.isEmpty()) View.VISIBLE else View.GONE
            binding.layoutContent.visibility = if (playlists.isNotEmpty()) View.VISIBLE else View.GONE
        }

        viewModel.groups.observe(this) { groups ->
            groupAdapter.submitList(groups)
        }

        viewModel.channels.observe(this) { channels ->
            channelAdapter.submitList(channels)
            binding.tvChannelCount.text = "${channels.size} channels"
        }

        viewModel.selectedPlaylist.observe(this) { playlist ->
            supportActionBar?.subtitle = playlist?.name
        }

        viewModel.isLoading.observe(this) { loading ->
            binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
            binding.swipeRefresh.isRefreshing = false
        }

        viewModel.error.observe(this) { error ->
            error?.let {
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
                viewModel.clearError()
            }
        }
    }

    private fun setupClickListeners() {
        binding.fabAddPlaylist.setOnClickListener { showAddPlaylistDialog() }

        binding.swipeRefresh.setOnRefreshListener {
            viewModel.refreshCurrentPlaylist()
        }
    }

    private fun showAddPlaylistDialog() {
        val dialogBinding = DialogAddPlaylistBinding.inflate(layoutInflater)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.add_playlist)
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.save) { _, _ ->
                val name = dialogBinding.etName.text.toString().trim()
                val url = dialogBinding.etUrl.text.toString().trim()
                if (name.isNotEmpty() && url.isNotEmpty()) {
                    viewModel.addPlaylist(name, url)
                } else {
                    Toast.makeText(this, R.string.fill_all_fields, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun openPlayer(channel: Channel) {
        viewModel.markWatched(channel)
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_CHANNEL_NAME, channel.name)
            putExtra(PlayerActivity.EXTRA_STREAM_URL, channel.streamUrl)
            putExtra(PlayerActivity.EXTRA_CHANNEL_LOGO, channel.logoUrl)
            putExtra(PlayerActivity.EXTRA_CHANNEL_ID, channel.id)
            putExtra(PlayerActivity.EXTRA_TVG_ID, channel.tvgId)
            putExtra(PlayerActivity.EXTRA_PLAYLIST_ID, channel.playlistId)
        }
        startActivity(intent)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = false
            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.searchChannels(newText ?: "")
                return true
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_refresh -> { viewModel.refreshCurrentPlaylist(); true }
            R.id.action_manage -> {
                startActivity(Intent(this, PlaylistActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
