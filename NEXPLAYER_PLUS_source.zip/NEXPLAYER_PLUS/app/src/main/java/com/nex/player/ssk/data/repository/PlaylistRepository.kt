package com.nex.player.ssk.data.repository

import android.content.Context
import com.nex.player.ssk.data.model.*
import com.nex.player.ssk.util.M3uParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class PlaylistRepository(context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val playlistDao = db.playlistDao()
    private val channelDao = db.channelDao()

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    // ─── Playlists ───────────────────────────────────────────────────────────

    suspend fun getAllPlaylists(): List<Playlist> = withContext(Dispatchers.IO) {
        playlistDao.getAllPlaylists()
    }

    suspend fun addPlaylist(name: String, url: String): Result<Playlist> = withContext(Dispatchers.IO) {
        try {
            val playlist = Playlist(name = name, url = url)
            val id = playlistDao.insertPlaylist(playlist)
            val saved = playlist.copy(id = id)
            Result.success(saved)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deletePlaylist(playlist: Playlist) = withContext(Dispatchers.IO) {
        channelDao.deleteChannelsByPlaylist(playlist.id)
        playlistDao.deletePlaylist(playlist)
    }

    // ─── Channel loading ──────────────────────────────────────────────────────

    suspend fun refreshPlaylist(playlist: Playlist): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val content = fetchUrl(playlist.url)
            val channels = M3uParser.parse(content, playlist.id)
            if (channels.isEmpty()) return@withContext Result.failure(Exception("No channels found in playlist"))

            channelDao.deleteChannelsByPlaylist(playlist.id)
            channelDao.insertChannels(channels)

            val updated = playlist.copy(
                lastUpdated = System.currentTimeMillis(),
                channelCount = channels.size
            )
            playlistDao.updatePlaylist(updated)

            Result.success(channels.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getEpgUrlFromPlaylist(playlist: Playlist): String? = withContext(Dispatchers.IO) {
        try {
            val content = fetchUrl(playlist.url)
            M3uParser.extractEpgUrl(content)
        } catch (_: Exception) { null }
    }

    // ─── Channels ─────────────────────────────────────────────────────────────

    suspend fun getChannels(playlistId: Long): List<Channel> = withContext(Dispatchers.IO) {
        channelDao.getChannelsByPlaylist(playlistId)
    }

    suspend fun getGroups(playlistId: Long): List<String> = withContext(Dispatchers.IO) {
        channelDao.getGroupsByPlaylist(playlistId)
    }

    suspend fun getChannelsByGroup(playlistId: Long, group: String): List<Channel> = withContext(Dispatchers.IO) {
        channelDao.getChannelsByGroup(playlistId, group)
    }

    suspend fun searchChannels(playlistId: Long, query: String): List<Channel> = withContext(Dispatchers.IO) {
        channelDao.searchChannels(playlistId, query)
    }

    suspend fun getFavorites(playlistId: Long): List<Channel> = withContext(Dispatchers.IO) {
        channelDao.getFavoriteChannels(playlistId)
    }

    suspend fun getRecentChannels(playlistId: Long): List<Channel> = withContext(Dispatchers.IO) {
        channelDao.getRecentChannels(playlistId)
    }

    suspend fun toggleFavorite(channel: Channel) = withContext(Dispatchers.IO) {
        channelDao.updateFavorite(channel.id, !channel.isFavorite)
    }

    suspend fun markWatched(channelId: Long) = withContext(Dispatchers.IO) {
        channelDao.updateLastWatched(channelId, System.currentTimeMillis())
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private fun fetchUrl(url: String): String {
        val request = Request.Builder().url(url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw Exception("HTTP ${response.code}")
            return response.body?.string() ?: throw Exception("Empty response")
        }
    }
}
