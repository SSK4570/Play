package com.nex.player.ssk.data.repository

import android.content.Context
import com.nex.player.ssk.data.model.AppDatabase
import com.nex.player.ssk.data.model.EpgProgram
import com.nex.player.ssk.util.EpgParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayInputStream
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream

class EpgRepository(context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val epgDao = db.epgDao()

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    suspend fun fetchAndSaveEpg(epgUrl: String, playlistId: Long): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val content = fetchEpgContent(epgUrl)
            val programs = EpgParser.parse(content, playlistId)
            if (programs.isEmpty()) return@withContext Result.failure(Exception("No EPG data found"))

            epgDao.deleteEpgByPlaylist(playlistId)
            epgDao.insertPrograms(programs)

            // Clean old programs
            val yesterday = System.currentTimeMillis() - 24 * 60 * 60 * 1000
            epgDao.deleteOldPrograms(yesterday)

            Result.success(programs.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getCurrentProgram(tvgId: String): EpgProgram? = withContext(Dispatchers.IO) {
        epgDao.getCurrentProgram(tvgId, System.currentTimeMillis())
    }

    suspend fun getProgramsForChannel(tvgId: String): List<EpgProgram> = withContext(Dispatchers.IO) {
        epgDao.getProgramsForChannel(tvgId, System.currentTimeMillis())
    }

    private fun fetchEpgContent(url: String): String {
        val request = Request.Builder().url(url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw Exception("HTTP ${response.code}")
            val bytes = response.body?.bytes() ?: throw Exception("Empty response")

            // Auto-detect GZIP
            return if (url.endsWith(".gz") || isGzip(bytes)) {
                GZIPInputStream(ByteArrayInputStream(bytes)).bufferedReader().readText()
            } else {
                String(bytes, Charsets.UTF_8)
            }
        }
    }

    private fun isGzip(bytes: ByteArray): Boolean =
        bytes.size >= 2 && bytes[0] == 0x1f.toByte() && bytes[1] == 0x8b.toByte()
}
