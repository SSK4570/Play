package com.nex.player.ssk.ui.home

import androidx.lifecycle.*
import com.nex.player.ssk.data.model.Channel
import com.nex.player.ssk.data.model.Playlist
import com.nex.player.ssk.data.repository.EpgRepository
import com.nex.player.ssk.data.repository.PlaylistRepository
import kotlinx.coroutines.launch

class MainViewModel(
    private val playlistRepo: PlaylistRepository,
    private val epgRepo: EpgRepository
) : ViewModel() {

    private val _playlists = MutableLiveData<List<Playlist>>()
    val playlists: LiveData<List<Playlist>> = _playlists

    private val _channels = MutableLiveData<List<Channel>>()
    val channels: LiveData<List<Channel>> = _channels

    private val _groups = MutableLiveData<List<String>>()
    val groups: LiveData<List<String>> = _groups

    private val _selectedPlaylist = MutableLiveData<Playlist?>()
    val selectedPlaylist: LiveData<Playlist?> = _selectedPlaylist

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    private var allChannels: List<Channel> = emptyList()
    private var currentGroup: String = ""
    private var searchQuery: String = ""

    fun loadPlaylists() = viewModelScope.launch {
        _playlists.value = playlistRepo.getAllPlaylists()
        val first = _playlists.value?.firstOrNull()
        if (first != null) selectPlaylist(first)
    }

    fun selectPlaylist(playlist: Playlist) = viewModelScope.launch {
        _selectedPlaylist.value = playlist
        currentGroup = ""
        searchQuery = ""
        loadChannelsForPlaylist(playlist)
        loadGroupsForPlaylist(playlist)

        // Auto-load EPG if channels are present
        val epgUrl = playlistRepo.getEpgUrlFromPlaylist(playlist)
        if (epgUrl != null) {
            epgRepo.fetchAndSaveEpg(epgUrl, playlist.id)
        }
    }

    private suspend fun loadChannelsForPlaylist(playlist: Playlist) {
        _isLoading.value = true
        allChannels = playlistRepo.getChannels(playlist.id)
        if (allChannels.isEmpty()) {
            // Try to refresh if no channels yet
            val result = playlistRepo.refreshPlaylist(playlist)
            result.onSuccess { allChannels = playlistRepo.getChannels(playlist.id) }
            result.onFailure { _error.value = "Failed to load: ${it.message}" }
        }
        applyFilters()
        _isLoading.value = false
    }

    private suspend fun loadGroupsForPlaylist(playlist: Playlist) {
        val groups = playlistRepo.getGroups(playlist.id)
        _groups.value = listOf("All") + groups
    }

    fun selectGroup(group: String) = viewModelScope.launch {
        currentGroup = group
        applyFilters()
    }

    fun searchChannels(query: String) = viewModelScope.launch {
        searchQuery = query
        applyFilters()
    }

    private fun applyFilters() {
        var filtered = allChannels
        if (currentGroup.isNotEmpty() && currentGroup != "All") {
            filtered = filtered.filter { it.group == currentGroup }
        }
        if (searchQuery.isNotEmpty()) {
            val q = searchQuery.lowercase()
            filtered = filtered.filter {
                it.name.lowercase().contains(q) || it.tvgName.lowercase().contains(q)
            }
        }
        _channels.value = filtered
    }

    fun refreshCurrentPlaylist() = viewModelScope.launch {
        val playlist = _selectedPlaylist.value ?: return@launch
        _isLoading.value = true
        val result = playlistRepo.refreshPlaylist(playlist)
        result.onSuccess {
            allChannels = playlistRepo.getChannels(playlist.id)
            applyFilters()
            _playlists.value = playlistRepo.getAllPlaylists()
        }
        result.onFailure { _error.value = "Refresh failed: ${it.message}" }
        _isLoading.value = false
    }

    fun addPlaylist(name: String, url: String) = viewModelScope.launch {
        _isLoading.value = true
        val result = playlistRepo.addPlaylist(name, url)
        result.onSuccess { playlist ->
            val refreshResult = playlistRepo.refreshPlaylist(playlist)
            refreshResult.onFailure { _error.value = "Added playlist but couldn't load channels: ${it.message}" }
            _playlists.value = playlistRepo.getAllPlaylists()
            selectPlaylist(playlist)
        }
        result.onFailure { _error.value = "Failed to add playlist: ${it.message}" }
        _isLoading.value = false
    }

    fun toggleFavorite(channel: Channel) = viewModelScope.launch {
        playlistRepo.toggleFavorite(channel)
        allChannels = allChannels.map {
            if (it.id == channel.id) it.copy(isFavorite = !it.isFavorite) else it
        }
        applyFilters()
    }

    fun markWatched(channel: Channel) = viewModelScope.launch {
        playlistRepo.markWatched(channel.id)
    }

    fun clearError() { _error.value = null }
}

class MainViewModelFactory(
    private val playlistRepo: PlaylistRepository,
    private val epgRepo: EpgRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return MainViewModel(playlistRepo, epgRepo) as T
    }
}
